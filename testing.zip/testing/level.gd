extends Node2D

var meteor_scene: PackedScene = load("res://testing/meteor.tscn")
func _on_meteor_timer_timeout():
	var meteor = meteor_scene.instantiate()
	add_child(meteor)
